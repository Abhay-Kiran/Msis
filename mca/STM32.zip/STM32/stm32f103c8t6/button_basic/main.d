main.o: main.c \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/rcc.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/cm3/common.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdint.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdbool.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/memorymap.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/f1/memorymap.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/cm3/memorymap.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/f1/rcc.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/common/rcc_common_all.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/gpio.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/f1/gpio.h \
 /home/ved/ME/MCA/STM32/stm32f103c8t6/libopencm3/include/libopencm3/stm32/common/gpio_common_all.h
