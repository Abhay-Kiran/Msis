#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>

static void
gpio_setup(void)
{

    /*Enable GPIOA clock.*/
    rcc_periph_clock_enable(RCC_GPIOA);
    gpio_set_mode(GPIOA, GPIO_MODE_INPUT,
                  GPIO_CNF_INPUT_PULL_UPDOWN, GPIO3);

    gpio_set(GPIOA, GPIO3);

    /*Set GPIO0 (in GPIO port A) to 'output push-pull.*/
    gpio_set_mode(GPIOA, GPIO_MODE_OUTPUT_2_MHZ,
                  GPIO_CNF_OUTPUT_PUSHPULL, GPIO0);
}

int main(void)
{
    int i;
    int count = 0;
    gpio_setup();

    while (1)
    {

        if (gpio_get(GPIOA, GPIO3) == 0)
        {
            count++;
            for (int j = 0; j < count; j++)
            {
               
                gpio_set(GPIOA, GPIO0);
                for (i = 0; i < 1000000; i++)
                    __asm__("nop");
                gpio_clear(GPIOA, GPIO0);
                for (i = 0; i < 1000000; i++)
                    __asm__("nop");
            }
            while (gpio_get(GPIOA, GPIO3) == 0)
            {
                // wait
            }
        }
    }
    return 0;
}