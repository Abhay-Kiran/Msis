nvic.o: ../../cm3/nvic.c ../../../include/libopencm3/cm3/nvic.h \
 ../../../include/libopencm3/cm3/common.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdint.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdbool.h \
 ../../../include/libopencm3/cm3/memorymap.h \
 ../../../include/libopencm3/dispatch/nvic.h \
 ../../../include/libopencm3/efm32/g/nvic.h \
 ../../../include/libopencm3/cm3/scs.h
